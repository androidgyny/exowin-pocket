@echo off
CHCP 850 >NUL
cd %VAR%
..\..\..\..\util\setconsole.exe /reset
echo.
echo Pulse 1 para jugar a Castle Master en HERCULES 
echo Pulse 2 para jugar a Castle Master en VGA 
echo Pulse 3 para jugar a Castle Master en modo TANDY 
echo.
..\..\..\..\util\choice /C:123 /N Por favor elija:

if errorlevel = 3 goto tand
if errorlevel = 2 goto vga
if errorlevel = 1 goto herc


:herc
cls
echo.
echo El programa DOS se ha adaptado a HERCULES.
echo Al iniciar el juego Castle Master, cuando muestre varias
echo opciones gr�ficas, pulse:
echo                    1. Hercules monocromo
echo                       (tecla F11 cambia de color)
echo.
pause
cls
..\..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosboxhe.conf" -conf ".\emulators\dosbox\options.conf" -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:vga
cls
echo.
echo El programa DOS se ha adaptado a VGA.
echo Al iniciar el juego Castle Master, cuando muestre varias
echo opciones gr�ficas, pulse una de estas dos opciones:
echo                    2. CGA 4 colores
echo                    3. EGA 16 colores
echo.
pause
cls
..\..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosbox.conf" -conf ".\emulators\dosbox\options.conf" -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:tand
cls
echo.
echo El programa DOS se ha adaptado a modo TANDY.
echo Al iniciar el juego Castle Master, cuando muestre varias
echo opciones gr�ficas, pulse:
echo                    4. Tandy 16 colores
echo.
pause
cls
..\..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosboxta.conf" -conf ".\emulators\dosbox\options.conf" -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:end