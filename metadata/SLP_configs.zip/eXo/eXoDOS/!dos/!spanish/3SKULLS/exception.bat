@echo off
CHCP 850 >NUL
cd %VAR%
..\..\..\..\util\setconsole.exe /reset
echo.
echo Pulse 1 para jugar a 3 Skulls of the Toltecs con DOSBox
echo Pulse 2 para jugar a 3 Skulls of the Toltecs con ScummVM
echo.
..\..\..\..\util\choice /C:12 /N Por favor elija:

if errorlevel = 2 goto scummvm
if errorlevel = 1 goto dosbox

:dosbox
..\..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosbox.conf" -conf ".\emulators\dosbox\options.conf" -noconsole -exit
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:scummvm
cd ..
cd ..
cd ..
cd ..
cls
echo.
echo Pulse 1 para jugar con m�sica Sound Blaster
echo Pulse 2 para jugar con m�sica MT-32
echo Pulse 3 para jugar con m�sica Sound Canvas
echo.
.\util\choice /C:123 /N Por favor elija:

if errorlevel = 3 goto svmsU55
if errorlevel = 2 goto svmmU32
if errorlevel = 1 goto svUsb

:svUsb
.\util\setconsole.exe /minimize
".\emulators\!spanish\scummvm2.9.0\scummvm.exe" --no-console -F -g3x --aspect-ratio --language=es -p.\eXoDOS\!spanish\3SKULLS\3Skull\ toltecs
goto end

:svmmU32
.\util\setconsole.exe /minimize
".\emulators\!spanish\scummvm2.9.0\scummvm.exe" --no-console -F -g3x -emt32 --extrapath=.\mt32\ --aspect-ratio --language=es -p.\eXoDOS\!spanish\3SKULLS\3Skull\ toltecs
goto end

:svmsU55
.\util\setconsole.exe /minimize
".\emulators\!spanish\scummvm2.9.0\scummvm.exe" --no-console -F -g3x -efluidsynth --soundfont=.\mt32\soundcanvas.sf2 --aspect-ratio --language=es -p.\eXoDOS\!spanish\3SKULLS\3Skull\ toltecs
goto end


:end