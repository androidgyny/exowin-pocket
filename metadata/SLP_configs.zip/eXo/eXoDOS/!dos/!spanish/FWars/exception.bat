echo off
CHCP 850 >NUL
cd %VAR%
..\..\..\..\util\setconsole.exe /reset
echo.
echo Pulse 1 para jugar a Future Wars con DOSBox
echo Pulse 2 para jugar a Future Wars con ScummVM
echo.
echo.
echo  NOTA:
echo  La protecci�n DOS del juego est� desabilitada.
echo  En la versi�n ScummVM algunas veces seleccionando
echo  siempre el color "Negro", puede acceder al juego.
echo.
echo.
echo.
..\..\..\..\util\choice /C:12 /N Por favor elija:

if errorlevel = 2 goto scummvm
if errorlevel = 1 goto dosbox

:dosbox
..\..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosbox.conf" -conf ".\emulators\dosbox\options.conf" -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:scummvm
cd ..
cd ..
cd ..
cd ..
cls
echo.
echo Pulse 1 para jugar con m�sica Sound Blaster
echo Pulse 2 para jugar con m�sica MT-32
echo.
.\util\choice /C:12 /N Por favor elija:

if errorlevel = 2 goto svmmt32
if errorlevel = 1 goto svmsb

:svmsb
.\util\setconsole.exe /minimize
".\emulators\!spanish\scummvm2.9.0\scummvm.exe" --no-console -F -g3x --aspect-ratio -p.\eXoDOS\!spanish\FWars\scummvm\ fw
goto end

:svmmt32
.\util\setconsole.exe /minimize
".\emulators\!spanish\scummvm2.9.0\scummvm.exe" --no-console -F -g3x -emt32 --extrapath=.\mt32\ --aspect-ratio -p.\eXoDOS\!spanish\FWars\scummvm\ fw
goto end

:end