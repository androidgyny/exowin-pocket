echo off
CHCP 850 >NUL
del .\eXoDOS\!spanish\BudokanT\TANDY.SEL
cls
.\util\setconsole.exe /reset

:pick
cls
echo.
echo Pulse 1 para jugar a Budokan en CGA 
echo Pulse 2 para jugar a Budokan en EGA 
echo Pulse 3 para jugar a Budokan en modo Tandy 
echo.
echo Nota: El modo IBM Mode permite seleccionar PC Speaker,
echo GameBlaster, Sound Blaster, y Roland MT-32.
echo.
.\util\choice /C:123 /N Please Choose:

if errorlevel = 3 goto TANDY
if errorlevel = 2 goto EGA
if errorlevel = 1 goto CGA

:CGA
set MACHINE=CGA
goto dosbox

:EGA
set MACHINE=SVGA_S3
goto dosbox

:TANDY
set TANDY=YES
echo > ".\eXoDOS\BudokanT\TANDY.SEL"
set MACHINE=TANDY
goto dosbox

:dosbox
.\util\setconsole.exe /minimize
".\emulators\dosbox\%dosbox%" -conf ".\eXoDOS\!dos\!spanish\BudokanT\dosbox.conf" -conf ".\emulators\dosbox\options.conf" -conf %conf% -noconsole -exit -machine %MACHINE%
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:end