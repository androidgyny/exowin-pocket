echo off
..\..\..\..\util\setconsole.exe /minimize
cls
cd Soundtrack
For %%f in (*.zip) do set ZipFile=%%f
cd ..\..
for %%I in (.) do set GameDir=%%~nxI
cd ..
for %%I in (.) do set YearDir=%%~nxI
cd ..
for %%I in (.) do set PackDir=%%~nxI
cd ..
for %%I in (.) do set ProjDir=%%~nxI
cd ..
.\emulators\audio\foobar2000\foobar2000.exe ".\%ProjDir%\%PackDir%\%YearDir%\%GameDir%\Extras\Soundtrack\%ZipFile%"