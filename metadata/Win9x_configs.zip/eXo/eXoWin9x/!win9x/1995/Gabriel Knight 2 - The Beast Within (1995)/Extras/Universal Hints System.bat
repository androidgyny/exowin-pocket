echo off
..\..\..\..\util\setconsole.exe /minimize
cls
cd UHS
For %%f in (*.UHS) do set UHSFile=%%f
cd ..\..
for %%I in (.) do set GameDir=%%~nxI
cd ..
for %%I in (.) do set PackDir=%%~nxI
cd ..
for %%I in (.) do set ProjDir=%%~nxI
cd ..
for %%I in (.) do set YearDir=%%~nxI
cd ..\util\openuhs\
OpenUHS "..\..\..\eXo\%YearDir%\%ProjDir%\%PackDir%\%GameDir%\Extras\UHS\%UHSFile%"