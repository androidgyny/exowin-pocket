@echo off
..\..\..\..\util\setconsole.exe /minimize
@set var=%cd%
for %%I in (.) do set GameDir=%%~nxI
for %%f in (*^).bat) do set GameLaunch=%%f
set GameName=%GameLaunch:~0,-4%
set IndexName=%GameName:~0,-7%
cd ..
set var=%cd%
for %%I in (.) do set YearDir=%%~nxI
cd ..
cd ..
cd ..
.\util\9xlaunch86Box.bat