@echo off
set FOLDER=%CD%
..\..\..\..\util\install9x.bat
:exit