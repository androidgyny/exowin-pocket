@echo off
cd %VAR%
..\..\..\..\util\setconsole.exe /reset
echo.
echo Press 1 to play Deluxe Ski Jump (in Polish)
echo Press 2 to play Deluxe Ski Jump (in Czech)
echo Press 3 to quit
echo.
..\..\..\..\util\choice /C:123 /N Please choose:

if errorlevel = 3 goto end
if errorlevel = 2 goto CZ
if errorlevel = 1 goto PL

:PL
..\..\..\..\util\setconsole.exe /minimize 
cd ..
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosboxPL.conf" -conf ".\emulators\dosbox\options.conf" -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:CZ
..\..\..\..\util\setconsole.exe /minimize 
cd ..
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosboxCZ.conf" -conf ".\emulators\dosbox\options.conf" -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:end