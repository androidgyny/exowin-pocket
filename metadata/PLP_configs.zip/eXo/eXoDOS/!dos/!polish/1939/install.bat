@echo off
@set var=%cd%
@set FOLDER=%CD%
for %%I in (.) do set GameDir=%%~nxI
for %%f in (*^).bat) do set GameName2=%%f
set GameName=%GameName2:~0,-4%
set IndexName=%GameName:~0,-7%
cd ..
cd ..
cd ..
cd ..
for %%a in (%var%) do for %%b in ("%%~dpa\.") do set "languagefolder=%%~nxb"
.\util\!languagepacks\install.bat