@echo off
cd %VAR%
..\..\..\..\util\setconsole.exe /reset
echo.
echo Press 1 to play Robbo
echo Press 2 to play Robbo (1989 demo)
echo Press 3 to quit
echo.
..\..\..\..\util\choice /C:123 /N Please choose:

if errorlevel = 3 goto end
if errorlevel = 2 goto demo
if errorlevel = 1 goto robbo

:robbo
..\..\..\..\util\setconsole.exe /minimize 
cd ..
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosbox.conf" -conf ".\emulators\dosbox\options.conf" -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:demo
..\..\..\..\util\setconsole.exe /minimize 
cd ..
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosboxega.conf" -conf ".\emulators\dosbox\options.conf" -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:end