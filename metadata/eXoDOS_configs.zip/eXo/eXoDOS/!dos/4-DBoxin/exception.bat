echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo Press 1 for 4-D Boxing IBM PC version
echo Press 2 for 4-D Boxing Tandy version
echo.
..\..\..\util\choice /C:12 /N Please Choose:

if errorlevel = 2 goto tandy
if errorlevel = 1 goto pc

:tandy
..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosbox_tandy.conf" -conf ".\emulators\dosbox\options.conf" -conf %conf% -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:pc
..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosbox.conf" -conf ".\emulators\dosbox\options.conf" -conf %conf% -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end