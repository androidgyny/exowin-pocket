echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo Press 1 to play Seven Cities of Gold in PCJR mode
echo Press 2 to play Seven Cities of Gold in CGA mode
echo.
echo The two modes use different color palletes and
echo sound is enhanced when using PCJR mode
echo.
..\..\..\util\choice /C:12 /N Please Choose:

if errorlevel = 2 goto CGA
if errorlevel = 1 goto PCJR

:CGA
..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosbox.conf" -conf ".\emulators\dosbox\options.conf" -conf %conf% -noconsole -exit -machine cga
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:PCJR
..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosbox.conf" -conf ".\emulators\dosbox\options.conf" -conf %conf% -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end