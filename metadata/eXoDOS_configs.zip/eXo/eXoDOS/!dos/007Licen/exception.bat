@echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo Press 1 to play 007 - Licence to Kill using DOSBox with EGA
echo Press 2 to play 007 - Licence to Kill using DOSBox with CGA
echo Press 3 to play 007 - Licence to Kill using DOSBox with Hercules
echo.
..\..\..\util\choice /C:123 /N Please Choose:

if errorlevel = 3 goto dosboxH
if errorlevel = 2 goto dosboxC
if errorlevel = 1 goto dosboxE

:dosboxE
..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosbox.conf" -conf ".\emulators\dosbox\options.conf" -conf %conf% -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:dosboxH
..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosboxH.conf" -conf ".\emulators\dosbox\options.conf" -conf %conf% -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:dosboxC
..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosboxC.conf" -conf ".\emulators\dosbox\options.conf" -conf %conf% -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:end