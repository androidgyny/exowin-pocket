@echo off
for /F "delims=" %%a in ('dir /A:D /B') DO (
echo "%%a"
cd %%a
FOR %%i in ("*).bat") DO echo %%a; %%~ni.zip >>E:\a2gs.txt
cd ..
)
