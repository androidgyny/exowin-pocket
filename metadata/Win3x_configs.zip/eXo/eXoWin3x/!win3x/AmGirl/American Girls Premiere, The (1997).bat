@echo off  
..\..\..\util\setconsole.exe /minimize  
@set var=%cd%
for %%I in (.) do set GameDir=%%~nxI
cd .. 
cd .. 
cd .. 
IF NOT EXIST ".\eXoWin3x\%GameDir%\" goto none 
".\dosbox\ece\dosbox.exe" -conf "%var%\dosbox.conf" -noconsole -exit 
del stdout.txt 
del stderr.txt
del glide*.*
del OpenGL*.*
if exist .\eXoWin3x\CWSDPMI.swp del .\eXoWin3x\CWSDPMI.swp 
goto end 
:none 
.\util\setconsole.exe /reset  
cls 
echo. 
echo Game has not been installed 
echo. 
echo.
echo Would you like to install the game? 
echo. 
.\util\CHOICE 

if errorlevel = 2 goto no
if errorlevel = 1 goto yes
:yes
cd %VAR% 
call install.bat
goto end
:no
goto end

:end 
