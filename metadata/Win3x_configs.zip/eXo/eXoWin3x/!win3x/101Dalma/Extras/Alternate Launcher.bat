@echo off
cd ..
@set var=%cd%
for %%I in (.) do set GameDir=%%~nxI
cd ..
cd ..
cd ..
IF NOT EXIST ".\eXoWin3x\%GameDir%\" goto none
cls
echo.
echo Press 1 for Pixel Perfect mode
echo Press 2 for Curved CRT mode
echo Press 3 for No Scan Lines mode
echo Press 4 to Quit 
echo.
echo Please note, all of the above options are experimental.
echo There is a chance your game won't run at all in this mode.
echo.
echo Pixel Perfect attempts to properly emulate pixel ratio
echo Curved CRT emulates the effects of a CRT monitor
echo No Scan Line Mode removes scan lines from select FMV games
echo.
.\util\choice /C:1234 /N Please Choose:

if errorlevel = 4 goto quit
if errorlevel = 3 goto NSLmode
if errorlevel = 2 goto CRTmode
if errorlevel = 1 goto PPmode

:PPMode
set dosbox=".\dosbox\ece\dosbox.exe"
set conf=".\dosbox\ece\ECE_PP.conf"
IF EXIST .\dosbox\check.txt goto install
echo.
echo You have selected to play with Pixel Perfect mode.
echo This warning\explanation will only appears once.
echo Further info can be found in the read me file.
echo.
echo Pixel Perfect mode emulates the pixel ratio
echo of DOS Games as accurately as can be managed
echo with DOSBox, however it is not compatible with
echo all games and may cause issues - in some cases
echo making the game unplayable. If this happens
echo restart the game using the standard launch method.
echo.
echo Other potential benefits of choosing this
echo mode is that in some cases DOSBox will be
echo using a more accurate OPL Audio emulation
echo [nuked OPL] and have more accurate PC Speaker
echo emulation.
echo.
pause
echo.>>.\dosbox\check.txt
goto install

:CRTmode
set dosbox=".\dosbox\ece_svn\dosbox.exe"
set conf=".\dosbox\crt.conf"
copy ".\mt32\c*.rom" .\
goto install

:NSLmode
set dosbox=".\dosbox\svn\dosbox.exe"
set conf=".\dosbox\no_line.conf"
copy ".\mt32\c*.rom" .\
goto install

:install
.\util\setconsole.exe /minimize
%dosbox% -conf "%var%\dosbox.conf" -conf %conf% -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
del glide.*
del c*.rom
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end
:none
.\util\setconsole.exe /reset
cls
echo.
echo Game has not been installed
echo.
echo.
echo Would you like to install the game?
echo.
.\util\choice

if errorlevel = 2 goto no
if errorlevel = 1 goto yes
:yes
cd %VAR%
call install.bat
goto end
:no
goto end

:end
