@echo off 
set CONF=%CD%
for %%I in (.) do set GameDir=%%~nxI
for %%f in (*^).bat) do set GameName2=%%f
set GameName=%GameName2:~0,-4%
cd ..
cd ..
cd ..
IF EXIST "eXoWin3x\%GameName%.zip" goto next

cls
echo.
echo It appears you have not downloaded this game yet.
echo.
echo %GameName%'s download is:
.\util\wget\wget "https://exodos.the-eye.us/public/eXoDOS/Games/%GameName%.zip" --spider 2>&1 | .\util\wget\sed -ne "/^Length:/{s/^.*(//;s/).*$//;p}"
echo.
echo Would you like to download it?
echo.
.\util\choice /C:YN /N [Y]es or [N]o

If errorlevel = 2 goto end
If errorlevel = 1 goto download

:download
copy .\util\wget\wget.* .\eXoWin3x\
cd eXoWin3x
wget -np -c -R "index.html*" "https://exorlp.xyz/public/eXo/eXoWin3x/Games/%GameName%.zip"
del wget.*
cls
echo.
IF EXIST "%GameName%.zip" echo Game Downloaded Successfully
IF NOT EXIST "%GameName%.zip" echo There was an error downloading the game. Exiting...
pause
cd ..

:next
IF EXIST ".\eXoWin3x\%GameDir%\" GOTO dele
:unzip
copy .\util\unzip.exe .\eXoWin3x\unzip.exe
cd eXoWin3x
unzip "%GameName%.zip"
cd ..
goto config
:dele
@echo off 
cls
echo.
.\util\CHOICE Uninstall?
IF ERRORLEVEL 2 GOTO config
IF ERRORLEVEL 1 GOTO erase
:config
cls
echo.
echo Would you like to enable Aspect Correction?
.\util\choice /C:YN /N [Y]es or [N]o
 
If errorlevel = 2 goto aspect2
If errorlevel = 1 goto aspect
 
:aspect
.\util\ssr 0 aspect=false aspect=true "%CONF%\dosbox.conf"
.\util\ssr 0 output=surface output=overlay "%CONF%\dosbox.conf"
goto next
 
:aspect2
.\util\ssr 0 aspect=true aspect=false "%CONF%\dosbox.conf"

goto next

:next
cls
echo.
echo Would you like [F]ullscreen or [W]indowed?
echo.
.\util\choice /C:FW

if errorlevel = 2 goto wind
if errorlevel = 1 goto full

:wind
.\util\ssr 0 fullscreen=true fullscreen=false ".\eXoWin3x\!win3x\%GameDir%\dosbox.conf"
.\util\ssr 0 -f -F ".\eXoWin3x\!win3x\%GameDir%\%GameName%.bat"
goto scaler1

:full
.\util\ssr 0 fullscreen=false fullscreen=true ".\eXoWin3x\!win3x\%GameDir%\dosbox.conf"
.\util\ssr 0 -F -f ".\eXoWin3x\!win3x\%GameDir%\%GameName%.bat"
goto scaler1

:scaler1
cls
echo.
echo Would you like to change your graphics filter?
echo.
.\util\choice /C:YN /N [Y]es or [N]o

if errorlevel = 2 goto end
if errorlevel = 1 goto sy

:sy
cls
echo.
echo Press 1 for no scaler
echo Press 2 for normal3x
echo Press 3 for hq2x
echo Press 4 for hq3x
echo Press 5 for 2xsai
echo Press 6 for super2xsai
echo press 7 for advmame2x
echo press 8 for advmame3x
echo press 9 for tv2x
echo Press 0 for normal2x
echo.
.\util\choice /C:1234567890 /N

if errorlevel = 10 goto :normal2x
if errorlevel = 9 goto :scaltv2x
if errorlevel = 8 goto :scalam3x
if errorlevel = 7 goto :scalam2x
if errorlevel = 6 goto :scals2xs
if errorlevel = 5 goto :scal2xs
if errorlevel = 4 goto :scalhq3x
if errorlevel = 3 goto :scalhq2x
if errorlevel = 2 goto :scaln3x
if errorlevel = 1 goto :scalno

:scalno
set SC=none
goto scaler

:scaln3x
set SC=normal3x
goto scaler

:scalhq2x
set SC=hq2x
goto scaler

:scalhq3x
set SC=hq3x
goto scaler

:scal2xs
set SC=2xsai
goto scaler

:scals2xs
set SC=super2xsai
goto scaler

:scalam2x
set SC=advmame2x
goto scaler

:scalam3x
set SC=advmame3x
goto scaler

:scaltv2x
set SC=tv2x
goto scaler

:normal2x
set SC=normal2x
goto scaler

:scaler
.\util\ssr 0 scaler=none scaler=%SC% "%CONF%\dosbox.conf"
.\util\ssr 0 scaler=normal3x scaler=%SC% "%CONF%\dosbox.conf"
.\util\ssr 0 scaler=hq2x scaler=%SC% "%CONF%\dosbox.conf"
.\util\ssr 0 scaler=hq3x scaler=%SC% "%CONF%\dosbox.conf"
.\util\ssr 0 scaler=2xsai scaler=%SC% "%CONF%\dosbox.conf"
.\util\ssr 0 scaler=super2xsai scaler=%SC% "%CONF%\dosbox.conf"
.\util\ssr 0 scaler=advmame2x scaler=%SC% "%CONF%\dosbox.conf"
.\util\ssr 0 scaler=advmame3x scaler=%SC% "%CONF%\dosbox.conf"
.\util\ssr 0 scaler=tv2x scaler=%SC% "%CONF%\dosbox.conf"
.\util\ssr 0 scaler=normal2x scaler=%SC% "%CONF%\dosbox.conf"
goto end

:erase
rd /q /s ".\eXoWin3x\%GameDir%\"
:end
cd eXoWin3x
if exist unzip.exe erase unzip.exe
